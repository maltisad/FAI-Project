﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FAI_lab2.Models
{
    public class Vendori
    {
        public int VendoriID { get; set; }
        public string Emri { get; set; }
        public string Lokacioni { get; set; }
        public int NrKontaktues { get; set; }
        public int BankAccount { get; set; }   
    }
}
