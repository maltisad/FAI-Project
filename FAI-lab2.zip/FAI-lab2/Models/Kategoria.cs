﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FAI_lab2.Models
{
    public class Kategoria
    {
        public int KategoriaID { get; set; }
        public int Vlera { get; set; }
    }
}
