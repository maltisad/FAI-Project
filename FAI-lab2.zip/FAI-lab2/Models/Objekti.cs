﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FAI_lab2.Models
{
    public class Objekti
    {
        public Objekti() { }
        public int ObjektiID { get; set; }
        public string Lokacioni { get; set; }
    }
}
