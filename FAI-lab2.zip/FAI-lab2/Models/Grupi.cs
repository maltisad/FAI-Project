﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FAI_lab2.Models
{
    public class Grupi
    {
        public Grupi() { }

        public int GrupiID { get; set; }
        public string emriGrupit { get; set; }
        public int KategoriaID { get; set; }
    }
}
